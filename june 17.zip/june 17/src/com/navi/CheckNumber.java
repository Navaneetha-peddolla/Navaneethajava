package com.navi;

import java.util.Scanner;

public class CheckNumber {

	public static void main(String[] args) {
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number");
		num=sc.nextInt();
		if(num==0) {
			System.out.println("number is zero");
		}
		if(num>0)
		{
			System.out.println(" number is positive");
			
		}
        if(num<0)
        {
        	System.out.println("number is negative");
        	}
	}

}
