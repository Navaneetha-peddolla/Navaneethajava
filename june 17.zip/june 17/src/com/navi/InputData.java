package com.navi;

import java.util.Scanner;

public class InputData {

	public static void main(String[] args) {
		//declaration of variables
		String name;
		int age;
		float fees;
		double amount;
		char gen;
		//create an object
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		name=sc.nextLine();
		System.out.println("Enter age");
		age=sc.nextInt();
		System.out.println("Enter fees");
		fees=sc.nextFloat();
		System.out.println("Enter amount");
		amount=sc.nextDouble();
		System.out.println("Enter gender");
		gen=sc.next().charAt(0);
		System.out.println("Enter details");
		System.out.println("Name=" +name);
		System.out.println("Age=" +age);
		System.out.println("Fees=" +fees);
		System.out.println("Amount=" +amount);
		System.out.println("Gender=" +gen);
		
		
		

	}

}
