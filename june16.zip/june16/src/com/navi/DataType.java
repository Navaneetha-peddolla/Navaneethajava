package com.navi;

public class DataType {

	public static void main(String[] args) {
		int num;
		num=10;
		float fval=98.78f;
		double dval=87.45;
		char ch='A';
		String s="N";
		System.out.println("int num=" +num);
		System.out.println("float fval=" +fval);
		System.out.println("double dval=" +dval);
		System.out.println("char ch=" +ch);
		System.out.println("String value s=" +s);
		

	}

}
