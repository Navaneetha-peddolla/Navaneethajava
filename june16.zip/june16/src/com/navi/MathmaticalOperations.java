package com.navi;

public class MathmaticalOperations {

	public static void main(String[] args) {
		int num1,num2,sum,sub;
		float div, mod;
		num1=10;
		num2=10;
		sum=num1+num2;
		System.out.println("The sum of " +num1+" and "+num2+" is "+sum);
		
		sub=num1-num2;
		System.out.println("The difference of " +num1+" and "+num2+" is "+sub);
		
		div=num1/num2;
		System.out.println("The quotient of " +num1+" and "+num2+" is "+div);
		
		mod=num1%num2;
		System.out.println("The Remainder of " +num1+" and "+num2+" is "+mod);

	}

}
