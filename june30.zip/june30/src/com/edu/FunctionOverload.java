package com.edu;

 class FunctionOverload1 { 
	void display() {
		System.out.println("with no arg");
	}
	void display(int i) {
		System.out.println("with 1 arg function type int");
	}
	void display(float i) {
	System.out.println("with 1 arg function type float ");
	}
	void display(double i) {
		System.out.println("with 1 arg function type double");
	}
	void display(char i) {
		System.out.println("with 1 arg function type char");
	}
	void display(int i,int j) {
		System.out.println("with 2 arg function type int");
	}
	void display(int i ,float j) {
		System.out.println("two arg one is int n one is float");
	}
	void display(float j,int i) {
		System.out.println("by interchanging arg 1st is float 2nd is int");
	}
	void display(short i,short j) {
		System.out.println("by interchanging arg 1st is float 2nd is int");
	}
 }
	
 
  public class FunctionOverload{
	  
	public static void main(String[] args) {
		FunctionOverload1 ob=new FunctionOverload1();
		ob.display();
		ob.display(20);
		ob.display(2.0f);
		ob.display(5.0);
		ob.display('A');
		ob.display(5,6);
		ob.display(6,2.1f);
		ob.display(5.0f,6);
        ob.display((short)5,(short)7);
	}

}
