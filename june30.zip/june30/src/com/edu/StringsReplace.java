package com.edu;

public class StringsReplace {

	public static void main(String[] args) {
		String s="TATA STEEL IS IN JAMSHEDPUR";
		String str="";
       for(int i=0;i<s.length();i++) {
    	   char ch=s.charAt(i);
    	   if(ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U'){
    		   str=str+"*";
    	   }
    	   else
    	   {
    	     str=str+ch;
    	   
    	   
    		   
    		   
    	   }
       }
       System.out.println(str);  
       
       /*String s="Vital Information Resource Under Seize ";
		String s1=" ";
	
		s1=s1+s.charAt(0); 
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch==' ') {
				s1=s1+s.charAt(i+1);
			}
		}
		System.out.println(s1);*/
		
	}

}
