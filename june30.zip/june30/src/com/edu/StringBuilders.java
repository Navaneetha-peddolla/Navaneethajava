package com.edu;

public class StringBuilders {

	public static void main(String[] args) {
		String s="Java";
		
		StringBuilder sb=new StringBuilder(s);  //to change the content
		System.out.println(sb.reverse()); 
		System.out.println(sb.append("india"));

	}

}
