package com.edu;

   class AddOverload{
	   
	   void add(int i, int j) {
		   System.out.println("adding two arg of type int:"  +(i+j));
		   
		   
	   }
	   void add(float i, float j) {
		   System.out.println("adding two arg of type float:" +(i+j));
		   
	   }
	   void add(double i, double j) {
		   System.out.println("adding two arg of type double:" +(i+j));
	   }
   }

public class OverloadAdd {

	public static void main(String[] args) {
		AddOverload ob=new AddOverload();
		ob.add(5,6);
		ob.add(2.0, 5.0);
		ob.add(5.1f, 2.0f);

	}
   }
