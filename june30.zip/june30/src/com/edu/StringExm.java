package com.edu;



public class StringExm {

	public static void main(String[] args) {
             String s="Computer is Fun";
		for(int i=s.length()-1;i>=0;i--) {
			System.out.println(s.charAt(i));
		}

	}

}
