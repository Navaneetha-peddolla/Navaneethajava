package com.edu;

public class OopsAdd {
	int a,b,s; //instance variable
	
	OopsAdd() { //constructor with no arguments
		a=10;
		b=10;
		System.out.println("constructor without arg");
	}
	
	OopsAdd(int i, int j){ //with arguments
		System.out.println(" constructor with arguments");
		a=i;
		b=j;
	}
	void add() { //method
		s=a+b;
		System.out.println("s=" +s);
	}

	public static void main(String[] args) {
		OopsAdd ob=new OopsAdd();
		OopsAdd ob1=new OopsAdd();
		ob.add();  //calling methods
		ob1.add();
		OopsAdd ob2=new OopsAdd(10,20);
		ob2.add();

	}

}
