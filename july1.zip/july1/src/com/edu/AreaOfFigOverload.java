package com.edu;
 
    class Areaoffigures {
    	//caluculate area of recatngle
    	void area(int l,int b) {
    		int area=l*b;
    		System.out.println("area of rectangle" +area);
    	}
    	//caluculate area of square
    	void area(int side){
    	    int area=side*side;
    	    System.out.println("Area of square " +area);
    	 }
    	//caluculate area of circle
    	void area(float r){
    	   float area;
    	   area=3.14159f*r*r;
    	   System.out.println("Area of a circle" +area);
    	 }
    	//traingle
    	void area(float b, float h){
    	     float area;
    	    area=(b*h)*0.5f;
    	   System.out.println("Area of a triangle " +area);
    	 
    	}
    	}

    	
    	

    

public class AreaOfFigOverload {

	public static void main(String[] args) {
		Areaoffigures ob = new Areaoffigures();
   	  ob.area(5);
   	  ob.area(6,8);
   	  ob.area(9.8f);
   	  ob.area(2.3f,5.6f);

	}

}
