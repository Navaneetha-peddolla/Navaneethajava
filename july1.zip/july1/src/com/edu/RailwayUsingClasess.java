package com.edu;

import java.util.Scanner;

class Railway{
	   String name,coach;
	   int amt,totalamt;
	   long mobile;
	   
	   // accept data
	   void accept() {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("enter name");
		   name=sc.next();
		   System.out.println("enter coach");
		   coach=sc.next();
		   System.out.println("enter moblie number");
		   mobile=sc.nextLong();
		   System.out.println("enter amt");
		   amt=sc.nextInt();
	   }  
		   
	   
   

       void update() {
    	   if(coach.equalsIgnoreCase("First_Ac")) {
    		   totalamt=amt+700;
    	   }
    	   else if(coach.equalsIgnoreCase("Second_Ac")) {
    		   totalamt=amt+500;
    	   }
    	   else if(coach.equalsIgnoreCase("Third_Ac")) {
    		   totalamt=amt+250;
    		   {
    			   totalamt=amt;
    		   }
    	   }
    	   else {
    		   System.out.println("invalid coach");{
    			   
    		   }
    			   
    		   }
    	   
       }
    	   
    	   
    	   
       
       
       void display() {
    	   System.out.println("Name:" +name);
    	   System.out.println("coach:" +coach);
    	   System.out.println("moblie:" +mobile );
    	   System.out.println("totalamt:" +totalamt);
    	   
       }
}

public class RailwayUsingClasess {

	public static void main(String[] args) {
		Railway rob=new Railway();
		rob.accept();
		rob.update();
		rob.display();

	}


}


