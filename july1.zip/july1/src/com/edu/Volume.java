package com.edu;

   class Volumeoverload{

      //caluculate sphere
	   void volume(double r) {
		   double v=(4/3*22/7*r*r*r);{
			   
		   System.out.println("volume of sphere:" +v);
	   }
	   }
	   
		   //caluculate volume of cylinder
	   void volume(double h, double r) {
		   double v=(22/7*r*r*h);{
			   System.out.println("volume of cylinder: " +v);
		   }
	   }
         //caluculate cuboid
	   void volume(double l, double b, double h) {
		   double v=l*b*h;{
			   System.out.println("volume of cuboid :"  +v);
		   }
	   }
	   
		  
	   
	  
	
   }

public class Volume {

	public static void main(String[] args) {
		
		Volumeoverload ob =new Volumeoverload();
		ob.volume(5);
		ob.volume(5,6);
		ob.volume(2,4,5);

	}

}
