package com.edu;

	import java.util.Scanner;

	class showroom{
		
		  String name;
		  long mobile;
		  double cost,discount,amt;
	
		  //constructor
		  showroom(){
			  mobile=0;
			  cost=0.0;
			  discount=0.0;
			  amt=0.0;
			  name=null;
		  }
		  
		  void input() {
			  Scanner sc=new Scanner(System.in);
			  System.out.println("enter the name");
			  name=sc.next();
			  System.out.println("enter mobile number");
			  mobile=sc.nextLong();
			  System.out.println("enter the cost");
			  cost=sc.nextInt();
			  
		  }
		 void caluculate() {
			 if(cost<=10000) {
				 discount=cost*5/100;
			 }
			 else if(cost>10000 && cost<=20000) {
				 discount=cost*10/100;
			 }
			 else if(cost>20000 && cost<=35000) {
				 discount=cost*15/100;
			 }
			 else if(cost>35000) {
				 discount=cost*20/100;
			 }
		 }
			 
			 void display() {
				 System.out.println("enter name" +name);
				 System.out.println("enter mobile number" +mobile);
				 System.out.println("enter cost");
			 }
			  }
	
	public class ShowRoom{
		public static void main(String[] args) {
			showroom sob=new showroom();
			sob.input();
			sob.caluculate();
			sob.display();
			}
	}
			 
